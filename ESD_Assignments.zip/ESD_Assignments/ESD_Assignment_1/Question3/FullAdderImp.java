import java.util.Scanner;

class FullAdderImp
{

	public static void main(String args[]){
		int num1 , num2 , cin , sum,cout=0,choice;
		Scanner sc = new Scanner(System.in);
		
		do{
		System.out.println("Enter the number a");
		num1 = sc.nextInt();
		System.out.println("Enter the number b");
		num2 = sc.nextInt();
		System.out.println("Enter the number cin");
		cin = sc.nextInt();

		/*----CORE LOGIC-----*/
		sum = (num1+num2+cin)%2;   
		cout = (num1+num2+cin)/2;
		/*-----LOGIC END-----*/
		
		System.out.println("The Sum is : "+sum);
		System.out.println("The Carry Out is : "+cout);
		System.out.println("Enter 1 if you want to continue with other inputs else enter 0");
		choice = sc.nextInt();
	}while(choice != 0);
	}
}

